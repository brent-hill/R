freqtab <- function(data, cml = FALSE, countNA = FALSE, dec = 2) {

	var_name <- deparse(substitute(data))
	if (grepl("\\$", var_name)) {        # easier to check object type?
		# Split the string into data frame and variable names
		parts <- strsplit(var_name, "$", fixed=TRUE)[[1]]
		df_name <- parts[1]
		col_name <- parts[2]
		# Output the data frame and variable names
		cat("Data frame:", df_name, "\n")
		cat("Variable:  ", col_name, "\n")
	} else {
		# Output the variable name if not from a data frame
		cat("Variable:", var_name, "\n")
	}
	
	# Checks object types of input data
	# - Atomic vector or column from data frame

	# Need to check for numeric vector or factor/ordered
	# - Stop/throw error if other

	# Convert data to factor if not already
	if(is.factor(data)==FALSE) {
		data <- factor(data)
	}

	# Create a frequency table
	if(countNA) {
		ftab <- table(data, useNA="always")
	} else {
		ftab <- table(data, useNA="no")
	}

	# Output container
	output <- list()

	# Distinct values of the variable
	output[["Values"]] <- names(ftab)
	# Frequencies
	output[["f"]] <- as.integer(ftab)
	# Relative frequencies
	output[["rf"]] <- as.numeric(prop.table(ftab))
	if(cml) {
		# Cumulative frequencies
		output[["cf"]] <- as.integer(cumsum(ftab))
		# Cumulative relative frequencies
		output[["crf"]] <- as.numeric(cumsum(prop.table(ftab)))
	}

	col_names <- names(output)
	num_cols <- length(output)
	num_rows <- length(output[["Values"]])
	# col_widths <- sapply(output, function(col) max(nchar(as.character(col_names)), max(nchar(as.character(col)))))
	format_string <- "%-8s %4d %7.2f %6d %8.2f"

	# Header
	cat(sprintf("%-8s %4s %7s %6s %8s", "Values", "f", "rf", "cf", "crf"), "\n")

	# Table content
	for (i in 1:num_rows) {
		# row_values <- sapply(output, function(col) as.character(col[i]))
		cat(sprintf(format_string, output[[1]][i], output[[2]][i], output[[3]][i], output[[4]][i], output[[5]][i]), "\n")
	}
	cat("\n")
}
