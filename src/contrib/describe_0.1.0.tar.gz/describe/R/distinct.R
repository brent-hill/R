distinct <- function(x) {
	k <- length(table(x, useNA="no"))
	var_name <- deparse(substitute(x))
	cat("Variable:", var_name, "\n")
	cat("Number of distinct values:", paste0("\033[1m", k, "\033[22m"), "\n\n")
}